/*
 * CNC_UART_ISRs.h
 *
 *  Created on: Feb 21, 2023
 *      Author: ali20
 */

#ifndef INCLUDE_APP_ISRS_CNC_UART_ISRS_H_
#define INCLUDE_APP_ISRS_CNC_UART_ISRS_H_


void CNC_voidRxCallBack(void);


#endif /* INCLUDE_APP_ISRS_CNC_UART_ISRS_H_ */
