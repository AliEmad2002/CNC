/*
 * CNC_private.h
 *
 *  Created on: Sep 19, 2022
 *      Author: Ali Emad
 */

#ifndef _CNC_PRIVATE_H_
#define _CNC_PRIVATE_H_

#define WRONG_INTERPOLATION_POINT_ERR_CODE		0

#define MAX_PROBE_EXCEEDED_ERR_CODE				1

#endif /* _CNC_PRIVATE_H_ */
