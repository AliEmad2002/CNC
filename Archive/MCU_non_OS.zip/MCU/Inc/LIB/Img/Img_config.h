/*
 * Img_config.h
 *
 *  Created on: Nov 25, 2022
 *      Author: Ali Emad Ali
 */

#ifndef INCLUDE_LIB_IMG_IMG_CONFIG_H_
#define INCLUDE_LIB_IMG_IMG_CONFIG_H_

#define MAX_NUMBER_OF_EACH_SHAPE_PER_FRAME			100



#endif /* INCLUDE_LIB_IMG_IMG_CONFIG_H_ */
