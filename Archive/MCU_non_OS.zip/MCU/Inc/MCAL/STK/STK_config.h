/*
 * STK_config.h
 *
 *  Created on: Nov 1, 2022
 *      Author: Ali Emad Ali
 */

#ifndef INCLUDE_MCAL_STK_STK_CONFIG_H_
#define INCLUDE_MCAL_STK_STK_CONFIG_H_


#define CLK_SOURCE		STK_CLOCKSOURCE_AHB


#endif /* INCLUDE_MCAL_STK_STK_CONFIG_H_ */
